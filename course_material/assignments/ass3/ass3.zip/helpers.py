# COMP3311 20T3 Ass3 ... Python helper functions
# add here any functions to share between Python scripts 

